package com.app.model;

public class Film {
	private Integer id;
	private String titre;
	private String realisateur;	
	
	public Film() {
		super();
	}
	public Film(String titre, String realisateur) {
		this();
		this.titre = titre;
		this.realisateur = realisateur;
	}
	public Film(Integer id, String titre, String realisateur) {
		this(titre, realisateur);
		this.id = id;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public String getRealisateur() {
		return realisateur;
	}
	public void setRealisateur(String realisateur) {
		this.realisateur = realisateur;
	}
	
	@Override
	public String toString() {
		return getClass().getSimpleName() + "{" 
				+ "Id: " + id + ", "
				+ "titre:" + titre + ", "
				+ "realisateur: " + realisateur
				+ "}";
	}
}
