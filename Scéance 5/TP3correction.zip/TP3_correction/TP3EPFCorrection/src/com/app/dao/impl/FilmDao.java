package com.app.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.app.dao.IFilmDao;
import com.app.exception.DaoException;
import com.app.model.Film;
import com.app.utils.EstablishConnection;


/*
 * Ici, comme dans le tp, la DAO est une classe qui va impl�menter une interface (ici IFilmDao)
 * qui d�fini plusieurs m�thode CRUD. Seule nouveaut�s ici:
 
 			res = preparedStatement.getGeneratedKeys();
			res.next();
			id = res.getInt(1);
 
 * Ces lignes ont pour but de r�cup�rer le ou les id(s) des �l�ments qui ont �t� cr�es
 * Ici un seul �l�ments est cr�er � la fois, donc le ResultSet res contiendra un seul r�sultat
 * en position 1. L'option Statement.RETURN_GENERATED_KEYS ajout�e au preparedStatement force 
 * la statement � stocker les ids g�n�r�s lors de la cr�ation.
 * Comme indiqu� dans les commentaires sur la Servlet, il est parfois n�cessaire de retourner 
 * l'identifiant de la ressource alt�r�e. A noter qu'il existe plusieurs autres m�thodes 
 * executeXXX() qui peuvent potentiellement vous renvoyer le ResultSet contenant l'identifiant.
 * On pref�re encapsuler ici les exceptions de type Sql, et les encapsuler si possible dans 
 * nos propres exceptions (DaoException).
 * classe 
 */
public class FilmDao implements IFilmDao {
	
	// Une impl�mentation possible du design pattern Singleton dite "lazy instanciation"
	private static FilmDao instance;
	private FilmDao() { }	
	public static IFilmDao getInstance() {
		if(instance == null) {
			instance = new FilmDao();
		}
		return instance;
	}
	
	private static final String CREATE_QUERY = "INSERT INTO Film (titre, realisateur) VALUES (?, ?);";
	private static final String SELECT_ONE_QUERY = "SELECT * FROM Film WHERE id=?;";
	private static final String SELECT_ALL_QUERY = "SELECT * FROM Film;";
	private static final String UPDATE_QUERY = "UPDATE Film SET titre=?, realisateur=? WHERE id=?;";
	private static final String DELETE_QUERY = "DELETE FROM Film WHERE id=?;";


	@Override
	public int create(Film film) throws DaoException {
		ResultSet res = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int id = -1;
		try {
			connection = EstablishConnection.getConnection();
			preparedStatement = connection.prepareStatement(CREATE_QUERY, Statement.RETURN_GENERATED_KEYS);
			preparedStatement.setString(1, film.getTitre());
			preparedStatement.setString(2, film.getRealisateur());
			preparedStatement.executeUpdate();
			res = preparedStatement.getGeneratedKeys();
			if(res.next()){
				id = res.getInt(1);				
			}

			System.out.println("CREATE: " + film);
		} catch (SQLException e) {
			throw new DaoException("Probl�me lors de la cr�ation du film: " + film, e);
		} finally {
			// Ici pour bien faire les choses on doit fermer les objets utilis�s dans
			// des blocs s�par�s afin que les exceptions lev�es n'emp�chent pas la fermeture des autres !
			// la logique est la m�me pour les autres m�thodes. Pour rappel, le bloc finally sera toujours ex�cut� !
			try {
				res.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return id;
	}

	@Override
	public Film getFilm(int id) throws DaoException {
		Film film = new Film();
		ResultSet res = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = EstablishConnection.getConnection();
			preparedStatement = connection.prepareStatement(SELECT_ONE_QUERY);
			preparedStatement.setInt(1, id);
			res = preparedStatement.executeQuery();
			if(res.next()) {
				film.setId(res.getInt("id"));
				film.setTitre(res.getString("titre"));
				film.setRealisateur(res.getString("realisateur"));				
			}
			
			System.out.println("GET: " + film);
		} catch (SQLException e) {
			throw new DaoException("Probl�me lors de la r�cup�ration du film: id=" + id, e);
		} finally {
			try {
				res.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return film;
	}

	@Override
	public List<Film> getFilms() throws DaoException {
		List<Film> films = new ArrayList<>();
		
		try (Connection connection = EstablishConnection.getConnection();
			 PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_QUERY);
			 ResultSet res = preparedStatement.executeQuery();
				){
			while(res.next()) {
				Film f = new Film(res.getInt("id"), res.getString("titre"), res.getString("realisateur"));
				films.add(f);
			}
			System.out.println("GET: " + films);
		} catch (SQLException e) {
			throw new DaoException("Probl�me lors de la r�cup�ration de la liste des films", e);
		}
		return films;
	}

	@Override
	public int update(Film film) throws DaoException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = EstablishConnection.getConnection();
			preparedStatement = connection.prepareStatement(UPDATE_QUERY);
			preparedStatement.setString(1, film.getTitre());
			preparedStatement.setString(2, film.getRealisateur());
			preparedStatement.setInt(3, film.getId());
			preparedStatement.executeUpdate();

			System.out.println("UPDATE: " + film);
		} catch (SQLException e) {
			throw new DaoException("Probl�me lors de la mise � jour du film: " + film, e);
		} finally {
			try {
				preparedStatement.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return film.getId();
	}

	@Override
	public int delete(Film film) throws DaoException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = EstablishConnection.getConnection();
			preparedStatement = connection.prepareStatement(DELETE_QUERY);
			preparedStatement.setInt(1, film.getId());
			preparedStatement.executeUpdate();
			preparedStatement.close();
			connection.close();
			System.out.println("DELETE: " + film);
		} catch (SQLException e) {
			throw new DaoException("Probl�me lors de la suppression du film: " + film, e);
		}  finally {
			try {
				preparedStatement.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return film.getId();
	}

} 