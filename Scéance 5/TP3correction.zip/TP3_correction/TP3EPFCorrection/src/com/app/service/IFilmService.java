package com.app.service;

import java.util.List;

import com.app.exception.ServiceException;
import com.app.model.Film;

public interface IFilmService {
	
	int create(String titre, String realisateur) throws ServiceException;
	
	Film getFilm(String id) throws ServiceException;
	Film getFilm(int id) throws ServiceException;
	
	List<Film> getFilms() throws ServiceException;
	
	int update(String id, String titre, String realisateur) throws ServiceException;
	
	int delete(String id) throws ServiceException;
}
